package com.yiban.han;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HanApplication {

	public static void main(String[] args) {
		SpringApplication.run(HanApplication.class, args);
	}

}
